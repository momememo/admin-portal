package com.baiwang.bop.manage.common.aspect.response;

/**
 * @Description:
 * @author: liyunfei
 * @date: 2018/10/26 21:44
 */
public class HiResponse {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
