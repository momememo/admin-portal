package com.baiwang.bop.manage.common.aspect.request;

/**
 * @Description:
 * @author: liyunfei
 * @date: 2018/10/26 21:43
 */
public class HiReuqest {

    private String name;
    private Integer Id;

    public HiReuqest(String name, Integer id) {
        this.name = name;
        Id = id;
    }
}
